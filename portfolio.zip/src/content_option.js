const logotext = "MSK";

const meta = {
  title: "Mathi MSK",
  description:
    "I’m Mathikumar B - Full stack devloper,currently working in Chennai",
};

const introdata = {
  title: "I’m Mathikumar B",
  animated: {
    first: "Full stack devloper",
    second: "I code cool websites",
    third: "I love coding",
  },
  description:
    "I have serious passion for UI effects , creating intuitive and dynamic user experiences. Let's make something special.",
  your_img_url: "https://images.unsplash.com/photo-1514790193030-c89d266d5a9d",
};

const dataabout = {
  title: "About my self",
  aboutme:
    "Hey There, I Am From Karaikudi. I Completed My Master Degree In Master Of Computer Applications From Rathanavel Subramaniam College Of Arts & Science, Sulur , Coimbatore. I Completed A Undergraduate Degree In Bachelor Of Computer Science From Vidhyaa Giri College Of Arts & Science, Puduvayal. I Like To Learn New Things. I Never Miss The Opportunity For New Things. Currently Working On CODIIS @ IIT Madras Research Park, Chennai.",
};
const worktimeline = [
  {
    jobtitle: "Full Stack Developer (Intern)",
    where: "CODIIS @ IIT Madras Research Park, Chennai",
    date: "02/01/2023 - 31/03/2023",
  },
  {
    jobtitle: "Full Stack Developer",
    where: "CODIIS @ IIT Madras Research Park, Chennai",
    date: "01/06/2023 - Present",
  },
  {
    jobtitle: "Full Stack Developer",
    where: "-",
    date: "-",
  },
];

const skills = [
  {
    name: "HTML & CSS",
    value: 70,
  },
  {
    name: "Javascript",
    value: 70,
  },
  {
    name: "Node.js",
    value: 80,
  },
  {
    name: "React",
    value: 80,
  },
];

const services = [
  {
    title: "UI & UX Design",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at nisl euismod urna bibendum sollicitudin.",
  },
  {
    title: "Mobile Apps",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at nisl euismod urna bibendum sollicitudin.",
  },
  {
    title: "Wordpress Design",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed at nisl euismod urna bibendum sollicitudin.",
  },
];

const dataportfolio = [
  {
    img: "https://picsum.photos/400/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/800/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/600/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/300/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/700/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },

  {
    img: "https://picsum.photos/400/600/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/300/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/550/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
  {
    img: "https://picsum.photos/400/700/?grayscale",
    description:
      "The wisdom of life consists in the elimination of non-essentials.",
    link: "#",
  },
];

const contactConfig = {
  YOUR_EMAIL: "mathimsk8@gmail.com",
  YOUR_FONE: "9487647805",
  description:
    "Living, learning, & leveling up one day at a time . If you want to recurit me, please fill the form or contact me in Social Media . I will get back to you as soon as possible. Thank you ",
  YOUR_SERVICE_ID: "service_msk3",
  YOUR_TEMPLATE_ID: "template_wfp6s9l",
  YOUR_PUBLIC_KEY: "AR6OScLtH4SG3MBLO",
};

const socialprofils = {
  github: "https://github.com/MathiMSK",
  facebook: "https://facebook.com",
  linkedin: "https://linkedin.com",
  twitter: "https://twitter.com",
};
export {
  meta,
  dataabout,
  dataportfolio,
  worktimeline,
  skills,
  services,
  introdata,
  contactConfig,
  socialprofils,
  logotext,
};
