import React, { useState } from "react";
import { IoMdMenu } from "react-icons/io";
import { IoCloseOutline } from "react-icons/io5";
import { logotext, socialprofils } from "../content_option";
import Themetoggle from "../components/themetoggle";
import { Typography } from "@mui/material";
import { Link } from "react-router-dom";
import "./styles.scss";
const Headermain = () => {
  const [isActive, setActive] = useState("false");

  const handleToggle = () => {
    setActive(!isActive);
    document.body.classList.toggle("ovhidden");
  };

  return (
    <>
      <header className="fixed-top site__header">
        <div className="d-flex align-items-center justify-content-between">
          <Typography
            className="navbar-brand nav_ac"
            fontWeight={"bolder"}
            style={{ fontSize: "25px", fontFamily: "'Julee', cursive" }}
          >
            {logotext}
          </Typography>
          <div className="d-flex align-items-center">
            <Themetoggle/>
            <button className="menu__button  nav_ac" onClick={handleToggle}>
              {!isActive ? <IoCloseOutline /> : <IoMdMenu />}
            </button>
          </div>
        </div>

        <div
          className={`site__navigation ${!isActive ? "menu__opend" : ""}`}
          style={{ display: "flex", justifyContent: "end" }}
        >
          <div
            className="bg__menu"
            style={{
              height: "50%",
              display: "flex",
              justifyContent: "flex-end",
              position: "relative",
            }}
          >
            <div className="menu__wrapper">
              <div className="menu__container p-3">
                <ul className="the_menu">
                  <li className="menu_item">
                    <Link
                      onClick={handleToggle}
                      to="/"
                      className="my-3"
                      style={{ fontSize: "25px" }}
                    >
                      Home
                    </Link>
                  </li>
                  <li className="menu_item">
                    <Link
                      onClick={handleToggle}
                      to="/portfolio"
                      className="my-3"
                      style={{ fontSize: "25px" }}
                    >
                      {" "}
                      Portfolio
                    </Link>
                  </li>
                  <li className="menu_item">
                    <Link
                      onClick={handleToggle}
                      to="/about"
                      className="my-3"
                      style={{ fontSize: "25px" }}
                    >
                      About
                    </Link>
                  </li>
                  <li className="menu_item">
                    <Link
                      onClick={handleToggle}
                      to="/contact"
                      className="my-3"
                      style={{ fontSize: "25px" }}
                    >
                      {" "}
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="menu_footer d-flex flex-column flex-md-row justify-content-between align-items-md-center position-absolute w-100 p-3">
            <div className="d-flex">
              <a href={socialprofils.facebook}>Facebook</a>
              <a href={socialprofils.github}>Github</a>
              <a href={socialprofils.twitter}>Twitter</a>
            </div>
            <p className="copyright m-0">All copyright@{logotext}</p>
          </div>
        </div>
      </header>
      <div className="br-top"></div>
      <div className="br-bottom"></div>
      <div className="br-left"></div>
      <div className="br-right"></div>
    </>
  );
};

export default Headermain;
